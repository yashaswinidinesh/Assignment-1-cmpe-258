package com.receipt2split.receipt2split

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
